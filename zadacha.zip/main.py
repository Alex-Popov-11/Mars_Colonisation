from flask import Flask, url_for, render_template, redirect
from flask_wtf import FlaskForm
from data import db_session
from data.users import User
from data.works import Work

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/works.db")
    app.run()


@app.route("/")
def index():
    db_sess = db_session.create_session()
    works = db_sess.query(Work)
    return render_template("index.html", works=works)


if __name__ == '__main__':
    main()
